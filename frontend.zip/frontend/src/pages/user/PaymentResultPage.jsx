import React, { useEffect, useState, useRef } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { paymentAPI } from '../../api/services';
import { Spinner } from '../../components/Common/UI';

export function PaymentResultPage() {
  const [searchParams]            = useSearchParams();
  const [status,     setStatus]   = useState('loading');
  const [orderData,  setOrderData] = useState(null);
  const pollingRef  = useRef(null);
  const hasRun      = useRef(false);

  const success     = searchParams.get('success');
  const momoOrderId = searchParams.get('momo_order_id') || sessionStorage.getItem('pending_momo_id');
  const amount      = searchParams.get('amount');
  const transId     = searchParams.get('trans_id');
  const message     = searchParams.get('message');

  useEffect(() => {
    if (hasRun.current) return;
    hasRun.current = true;

    const verify = async () => {
      // ── HỦY / THẤT BẠI ────────────────────────────────────────────────────
      // Order chưa tồn tại → không cần cancel gì, chỉ hiển thị UI
      if (success === '0' || !success) {
        sessionStorage.removeItem('pending_momo_id');
        setStatus('cancelled');
        return;
      }

      // ── SUCCESS=1 — polling session cho đến khi IPN xác nhận ──────────────
      if (!momoOrderId) { setStatus('failed'); return; }

      let attempts = 0;
      const MAX    = 10; // tối đa ~20 giây

      const poll = async () => {
        attempts++;
        try {
          const { data } = await paymentAPI.checkSessionStatus(momoOrderId);
          const s = data?.data?.status;

          if (s === 'paid') {
            clearInterval(pollingRef.current);
            sessionStorage.removeItem('pending_momo_id');
            setOrderData(data.data);
            setStatus('success');

          } else if (s === 'cancelled' || s === 'expired') {
            clearInterval(pollingRef.current);
            sessionStorage.removeItem('pending_momo_id');
            setStatus('failed');

          } else if (attempts >= MAX) {
            // IPN chưa về sau 20 giây → hiển thị lỗi, để user liên hệ hỗ trợ
            clearInterval(pollingRef.current);
            sessionStorage.removeItem('pending_momo_id');
            setStatus('timeout');
          }
          // s === 'pending' → tiếp tục poll
        } catch {
          clearInterval(pollingRef.current);
          setStatus('failed');
        }
      };

      await poll();
      pollingRef.current = setInterval(poll, 2000);
    };

    verify();
    return () => clearInterval(pollingRef.current);
  }, []); // eslint-disable-line

  const cfgs = {
    loading: {
      icon: null,
      title: 'Đang xác nhận thanh toán...',
      color: 'text-gray-600',
      desc:  'Vui lòng chờ trong giây lát',
      bg:    ''
    },
    success: {
      icon:  '✅',
      title: 'Thanh toán thành công!',
      color: 'text-green-600',
      desc:  'Đơn hàng đã được tạo. Cảm ơn bạn đã mua sắm!',
      bg:    'bg-green-50 border-green-100'
    },
    cancelled: {
      icon:  '↩️',
      title: 'Đã hủy thanh toán',
      color: 'text-amber-600',
      desc:  'Bạn đã hủy giao dịch. Không có đơn hàng nào được tạo.',
      bg:    'bg-amber-50 border-amber-100'
    },
    failed: {
      icon:  '❌',
      title: 'Thanh toán thất bại',
      color: 'text-red-600',
      desc:  (message && message !== 'null') ? message : 'Giao dịch không thành công. Vui lòng thử lại.',
      bg:    'bg-red-50 border-red-100'
    },
    timeout: {
      icon:  '⏳',
      title: 'Đang chờ xác nhận',
      color: 'text-yellow-600',
      desc:  'Hệ thống chưa nhận được xác nhận từ MoMo. Nếu tiền đã bị trừ, vui lòng liên hệ hỗ trợ.',
      bg:    'bg-yellow-50 border-yellow-100'
    },
  };

  const cfg = cfgs[status] || cfgs.failed;

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 w-full max-w-md p-8 text-center">

        {status === 'loading' ? (
          <>
            <div className="flex justify-center mb-4"><Spinner size="lg" /></div>
            <h1 className="text-xl font-semibold text-gray-700 mb-2">{cfg.title}</h1>
            <p className="text-sm text-gray-400">{cfg.desc}</p>
          </>
        ) : (
          <>
            <div className="text-6xl mb-4">{cfg.icon}</div>
            <h1 className={`text-2xl font-bold mb-2 ${cfg.color}`}>{cfg.title}</h1>
            <p className="text-gray-500 text-sm mb-6">{cfg.desc}</p>

            {/* Transaction details */}
            {(orderData?.order_id || transId || amount) && (
              <div className={`rounded-xl border p-4 mb-6 text-sm text-left space-y-2 ${cfg.bg}`}>
                {orderData?.order_id && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Mã đơn hàng</span>
                    <span className="font-mono font-semibold">#{String(orderData.order_id).slice(-10)}</span>
                  </div>
                )}
                {transId && transId !== 'null' && transId !== '' && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Mã GD MoMo</span>
                    <span className="font-mono text-xs">{transId}</span>
                  </div>
                )}
                {amount && amount !== '0' && amount !== 'null' && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Số tiền</span>
                    <span className="font-bold">{Number(amount).toLocaleString('vi-VN')}₫</span>
                  </div>
                )}
              </div>
            )}

            <div className="flex flex-col gap-3">
              {status === 'success' && (
                <Link to="/orders"
                  className="w-full py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition block">
                  Xem đơn hàng của tôi
                </Link>
              )}
              {(status === 'cancelled' || status === 'failed' || status === 'timeout') && (
                <Link to="/cart"
                  className="w-full py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition block">
                  Quay lại giỏ hàng
                </Link>
              )}
              <Link to="/"
                className="w-full py-3 border border-gray-200 text-gray-600 rounded-xl font-medium hover:bg-gray-50 transition block">
                Về trang chủ
              </Link>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default PaymentResultPage;